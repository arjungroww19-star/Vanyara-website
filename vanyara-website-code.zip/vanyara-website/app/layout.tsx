import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Vanyara Resort | Wellness in Wilderness',
  description: 'Ultra-luxury eco wellness resort and private nature residences near Dudhwa National Park.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
